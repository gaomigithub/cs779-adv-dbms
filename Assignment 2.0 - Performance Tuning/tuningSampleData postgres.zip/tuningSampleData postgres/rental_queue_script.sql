BEGIN;
INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1, 2952, date '2018/3/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1, 3207, date '2018/10/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1, 3157, date '2015/7/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(2, 2924, date '2015/6/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(2, 2506, date '2015/5/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(2, 1769, date '2018/4/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(3, 465, date '2015/6/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(3, 1689, date '2019/4/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(3, 3401, date '2016/12/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(3, 456, date '2019/3/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(4, 387, date '2017/2/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(5, 3268, date '2015/11/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(6, 1338, date '2016/5/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(6, 1123, date '2016/9/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(6, 2579, date '2019/3/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(7, 1212, date '2018/9/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(7, 1456, date '2015/6/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(7, 3174, date '2017/11/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(7, 2940, date '2019/12/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(8, 589, date '2016/5/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(8, 2902, date '2018/5/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(8, 601, date '2019/7/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(8, 2452, date '2018/1/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(9, 1371, date '2017/10/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(9, 2495, date '2019/9/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(9, 1377, date '2015/12/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(9, 2689, date '2018/7/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(10, 1142, date '2018/4/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(11, 1092, date '2018/8/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(11, 3280, date '2017/10/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(11, 1677, date '2016/10/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(12, 3012, date '2015/2/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(12, 2317, date '2016/1/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(12, 2084, date '2015/12/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(12, 1437, date '2018/8/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(13, 1095, date '2018/4/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(13, 831, date '2018/11/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(13, 626, date '2015/2/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(13, 846, date '2016/6/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(15, 186, date '2019/4/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(16, 1584, date '2015/2/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(16, 2058, date '2018/12/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(16, 3147, date '2017/9/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(16, 846, date '2017/2/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(17, 3178, date '2018/1/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(17, 1625, date '2018/10/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(20, 1427, date '2017/12/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(21, 1142, date '2019/6/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(21, 446, date '2015/1/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(22, 2913, date '2015/10/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(22, 2907, date '2015/2/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(22, 2686, date '2016/9/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(23, 236, date '2016/10/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(23, 2347, date '2016/11/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(24, 3197, date '2019/2/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(25, 1212, date '2015/7/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(25, 3598, date '2016/6/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(26, 1325, date '2017/6/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(27, 2648, date '2018/10/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(27, 2626, date '2017/8/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(27, 1768, date '2016/8/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(29, 2048, date '2015/10/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(30, 2908, date '2019/9/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(30, 1198, date '2018/5/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(31, 90, date '2019/4/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(31, 1285, date '2017/8/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(31, 699, date '2019/12/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(31, 2506, date '2018/2/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(32, 2210, date '2018/7/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(35, 2562, date '2019/3/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(35, 3334, date '2018/1/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(36, 2451, date '2016/7/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(36, 3435, date '2016/2/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(37, 3205, date '2016/5/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(37, 157, date '2017/6/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(37, 1471, date '2016/11/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(38, 2193, date '2015/4/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(39, 829, date '2018/7/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(40, 1600, date '2016/12/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(40, 500, date '2016/4/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(41, 3553, date '2016/10/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(42, 3353, date '2018/2/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(42, 2507, date '2016/2/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(44, 1526, date '2016/7/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(46, 3607, date '2019/7/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(46, 565, date '2015/10/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(46, 846, date '2017/10/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(47, 2209, date '2019/3/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(47, 2317, date '2015/2/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(47, 3023, date '2016/12/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(47, 971, date '2016/1/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(48, 679, date '2015/3/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(48, 2537, date '2019/7/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(50, 2114, date '2017/11/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(50, 1206, date '2017/10/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(50, 2044, date '2018/1/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(51, 1616, date '2019/4/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(51, 1449, date '2019/3/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(51, 2245, date '2015/12/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(52, 3183, date '2018/6/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(52, 3176, date '2016/7/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(52, 2544, date '2016/3/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(52, 1150, date '2015/2/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(53, 199, date '2018/5/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(55, 481, date '2015/2/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(55, 2832, date '2016/10/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(57, 2364, date '2016/6/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(57, 3205, date '2018/7/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(58, 2576, date '2019/6/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(58, 3077, date '2016/5/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(58, 3511, date '2016/8/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(58, 2061, date '2017/10/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(59, 2259, date '2015/11/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(59, 274, date '2015/12/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(59, 2332, date '2015/1/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(59, 39, date '2018/9/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(60, 1842, date '2018/12/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(60, 3403, date '2017/3/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(60, 261, date '2016/1/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(62, 217, date '2019/2/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(63, 272, date '2015/4/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(63, 2085, date '2015/7/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(63, 2340, date '2017/6/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(63, 1371, date '2018/6/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(64, 3407, date '2015/9/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(64, 3821, date '2016/3/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(65, 651, date '2019/6/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(66, 2866, date '2018/10/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(66, 1138, date '2015/5/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(66, 3672, date '2018/5/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(67, 3325, date '2017/8/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(68, 590, date '2019/5/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(68, 3407, date '2016/6/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(68, 260, date '2018/2/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(68, 3029, date '2019/6/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(69, 84, date '2015/9/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(69, 1200, date '2015/6/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(69, 2915, date '2016/9/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(69, 664, date '2018/1/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(70, 1822, date '2019/11/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(70, 3282, date '2016/9/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(70, 1290, date '2016/9/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(70, 2001, date '2016/4/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(72, 3570, date '2016/2/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(72, 2430, date '2017/10/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(72, 700, date '2017/7/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(75, 2963, date '2019/7/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(75, 2731, date '2018/1/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(75, 2298, date '2019/1/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(75, 3388, date '2017/10/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(76, 1054, date '2016/10/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(76, 3478, date '2016/9/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(76, 1386, date '2016/12/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(76, 1815, date '2018/7/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(77, 1138, date '2019/11/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(77, 1374, date '2015/11/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(77, 2455, date '2017/8/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(79, 752, date '2017/6/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(79, 669, date '2015/2/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(79, 1634, date '2015/7/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(79, 3159, date '2019/4/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(81, 2478, date '2015/3/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(82, 2355, date '2016/8/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(82, 1205, date '2016/3/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(83, 160, date '2018/4/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(83, 3278, date '2016/10/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(84, 1460, date '2016/2/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(84, 2613, date '2019/1/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(84, 3600, date '2017/12/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(84, 3796, date '2019/2/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(85, 3818, date '2016/1/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(85, 1102, date '2018/1/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(85, 2113, date '2015/5/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(85, 1613, date '2016/9/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(86, 1103, date '2018/1/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(87, 2436, date '2018/11/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(88, 3783, date '2016/12/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(88, 3084, date '2016/3/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(88, 478, date '2019/8/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(88, 2359, date '2018/7/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(89, 1066, date '2018/10/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(89, 3627, date '2017/12/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(89, 194, date '2016/2/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(90, 3081, date '2017/10/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(90, 3263, date '2016/10/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(90, 3850, date '2019/5/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(90, 2978, date '2017/1/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(91, 453, date '2016/4/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(91, 2990, date '2017/12/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(92, 914, date '2019/12/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(94, 142, date '2016/1/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(94, 1192, date '2015/10/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(96, 2492, date '2016/12/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(98, 950, date '2019/2/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(98, 2681, date '2019/11/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(98, 3848, date '2018/2/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(98, 3075, date '2017/10/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(99, 1489, date '2019/3/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(100, 381, date '2017/8/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(100, 3839, date '2018/2/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(100, 2209, date '2017/6/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(101, 3756, date '2017/7/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(101, 2122, date '2019/8/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(101, 325, date '2019/3/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(102, 3645, date '2017/4/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(102, 3720, date '2019/12/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(102, 2201, date '2017/7/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(104, 220, date '2015/8/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(104, 2170, date '2016/10/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(104, 2756, date '2018/11/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(104, 1319, date '2015/9/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(105, 1475, date '2017/11/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(105, 1930, date '2017/3/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(105, 2215, date '2019/8/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(106, 1590, date '2017/2/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(107, 489, date '2018/9/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(107, 3852, date '2018/7/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(107, 2726, date '2019/10/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(108, 1326, date '2015/10/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(108, 3547, date '2015/2/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(109, 1025, date '2016/8/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(109, 41, date '2018/6/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(110, 1569, date '2018/5/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(110, 1878, date '2015/10/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(110, 801, date '2017/7/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(110, 289, date '2017/9/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(111, 95, date '2019/10/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(111, 2787, date '2016/3/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(111, 3719, date '2018/6/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(112, 3807, date '2015/3/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(112, 1973, date '2019/6/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(113, 884, date '2015/8/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(113, 1880, date '2019/6/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(113, 2522, date '2016/7/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(115, 196, date '2018/1/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(115, 940, date '2019/10/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(115, 1078, date '2019/10/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(116, 474, date '2019/3/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(116, 3422, date '2019/11/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(116, 2633, date '2019/2/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(118, 1987, date '2015/12/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(118, 2161, date '2019/9/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(118, 3423, date '2018/11/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(118, 3669, date '2017/2/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(119, 2162, date '2017/7/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(119, 1417, date '2018/4/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(120, 2523, date '2017/11/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(120, 2451, date '2017/11/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(120, 3157, date '2019/4/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(122, 1042, date '2019/9/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(122, 1631, date '2019/4/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(123, 3219, date '2019/4/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(123, 1990, date '2016/5/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(123, 1857, date '2018/12/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(124, 1678, date '2017/3/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(124, 2722, date '2016/10/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(124, 2262, date '2018/7/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(125, 1306, date '2015/8/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(125, 3412, date '2017/7/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(125, 1903, date '2019/4/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(125, 2132, date '2017/2/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(126, 1852, date '2015/2/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(126, 1271, date '2016/8/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(126, 1878, date '2019/7/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(127, 1799, date '2019/7/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(127, 2745, date '2019/10/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(131, 1063, date '2017/9/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(131, 1760, date '2015/1/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(131, 1836, date '2016/7/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(131, 332, date '2016/9/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(132, 286, date '2019/2/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(133, 2020, date '2018/7/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(134, 1285, date '2015/5/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(134, 3042, date '2016/3/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(134, 3400, date '2018/9/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(134, 1499, date '2016/12/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(135, 1198, date '2018/1/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(135, 1083, date '2016/8/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(135, 5, date '2019/6/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(137, 2128, date '2018/7/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(137, 3108, date '2017/1/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(137, 3839, date '2015/12/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(137, 2820, date '2019/3/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(139, 126, date '2015/1/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(139, 1316, date '2018/11/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(139, 2917, date '2017/11/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(139, 1630, date '2017/1/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(141, 1750, date '2016/7/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(142, 2613, date '2015/7/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(142, 100, date '2015/3/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(145, 2629, date '2017/6/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(145, 256, date '2016/9/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(145, 1524, date '2017/6/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(145, 2086, date '2016/8/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(146, 1833, date '2018/1/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(146, 2476, date '2016/3/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(147, 679, date '2018/6/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(147, 1269, date '2018/12/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(147, 2316, date '2018/2/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(149, 3629, date '2016/7/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(149, 252, date '2019/9/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(150, 1864, date '2017/10/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(150, 457, date '2016/3/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(150, 837, date '2018/10/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(150, 299, date '2016/6/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(152, 2377, date '2018/7/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(152, 2822, date '2015/1/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(153, 1095, date '2016/1/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(154, 2357, date '2019/5/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(154, 3781, date '2019/2/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(154, 2805, date '2018/9/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(154, 2346, date '2018/7/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(156, 3314, date '2016/1/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(156, 2854, date '2017/3/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(156, 1098, date '2018/10/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(157, 3599, date '2019/10/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(157, 2042, date '2015/12/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(157, 1423, date '2016/5/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(157, 1999, date '2017/11/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(158, 3285, date '2016/1/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(159, 2747, date '2018/4/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(160, 1340, date '2017/2/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(160, 994, date '2019/1/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(160, 2369, date '2015/6/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(160, 3452, date '2018/3/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(161, 1048, date '2017/10/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(163, 280, date '2019/4/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(163, 3315, date '2016/6/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(166, 2641, date '2018/11/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(166, 888, date '2015/7/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(168, 2500, date '2016/6/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(168, 1743, date '2015/5/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(169, 762, date '2016/9/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(171, 2868, date '2016/1/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(171, 77, date '2019/1/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(171, 1510, date '2019/2/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(173, 1465, date '2019/5/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(173, 1026, date '2018/10/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(174, 2983, date '2017/3/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(176, 3842, date '2016/9/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(176, 731, date '2017/5/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(176, 1325, date '2019/7/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(176, 3277, date '2019/6/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(177, 1166, date '2016/2/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(177, 2644, date '2018/9/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(177, 2010, date '2018/12/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(178, 844, date '2018/4/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(180, 3836, date '2019/4/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(181, 2483, date '2019/1/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(181, 585, date '2017/2/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(181, 1485, date '2016/6/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(181, 3770, date '2016/9/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(182, 749, date '2018/12/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(182, 3429, date '2015/8/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(183, 748, date '2017/1/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(183, 1504, date '2019/5/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(183, 3373, date '2017/5/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(183, 1825, date '2019/9/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(184, 63, date '2019/6/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(184, 906, date '2017/5/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(185, 1830, date '2018/3/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(185, 2517, date '2017/12/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(185, 654, date '2018/6/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(185, 2928, date '2015/12/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(188, 1301, date '2016/8/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(188, 869, date '2016/12/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(189, 1690, date '2019/3/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(189, 586, date '2018/6/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(189, 3355, date '2017/3/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(189, 238, date '2016/5/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(192, 3882, date '2017/2/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(192, 2027, date '2015/12/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(192, 3805, date '2017/7/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(192, 985, date '2015/1/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(193, 3129, date '2018/11/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(193, 574, date '2018/2/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(194, 3709, date '2019/3/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(194, 3026, date '2019/12/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(194, 2598, date '2019/3/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(194, 1502, date '2019/5/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(196, 832, date '2016/3/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(196, 3158, date '2015/3/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(197, 2886, date '2017/5/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(197, 3406, date '2018/9/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(197, 318, date '2015/12/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(198, 1370, date '2019/2/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(198, 2246, date '2018/11/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(201, 3505, date '2015/8/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(201, 1158, date '2018/5/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(201, 1196, date '2017/2/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(202, 2479, date '2016/5/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(203, 1198, date '2019/2/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(203, 2176, date '2017/2/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(203, 956, date '2017/1/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(204, 1876, date '2017/5/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(204, 1418, date '2019/10/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(205, 1634, date '2019/3/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(205, 3309, date '2016/1/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(205, 2582, date '2018/7/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(205, 1201, date '2015/5/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(206, 1099, date '2016/10/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(206, 2542, date '2017/11/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(206, 2803, date '2016/4/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(207, 309, date '2019/8/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(207, 2737, date '2015/10/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(209, 2799, date '2015/8/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(209, 2265, date '2017/10/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(209, 192, date '2017/9/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(209, 3652, date '2015/3/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(210, 2212, date '2016/11/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(210, 1912, date '2018/1/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(211, 1522, date '2015/6/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(211, 1298, date '2017/4/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(211, 947, date '2016/11/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(211, 2670, date '2015/7/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(212, 3011, date '2016/2/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(212, 1190, date '2016/2/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(212, 2841, date '2015/3/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(213, 879, date '2015/5/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(214, 818, date '2019/2/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(214, 912, date '2016/8/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(215, 790, date '2015/12/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(215, 822, date '2015/11/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(215, 3283, date '2017/12/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(215, 1095, date '2016/12/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(216, 2172, date '2018/4/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(216, 2173, date '2017/9/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(217, 2718, date '2015/2/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(217, 3602, date '2015/12/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(218, 3879, date '2019/6/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(218, 1216, date '2018/10/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(219, 1744, date '2017/11/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(220, 2063, date '2017/3/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(220, 2790, date '2016/4/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(221, 2552, date '2016/6/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(221, 1628, date '2018/12/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(224, 552, date '2016/5/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(224, 1863, date '2015/4/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(224, 2366, date '2019/12/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(225, 2966, date '2018/5/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(225, 929, date '2019/12/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(225, 1631, date '2016/10/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(225, 123, date '2015/11/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(226, 3597, date '2017/11/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(227, 2547, date '2018/4/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(227, 2000, date '2018/2/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(227, 3891, date '2019/12/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(228, 684, date '2017/3/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(228, 2736, date '2019/10/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(228, 3275, date '2016/12/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(228, 1368, date '2017/5/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(229, 159, date '2016/12/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(229, 2539, date '2017/3/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(229, 683, date '2016/3/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(229, 2278, date '2018/2/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(230, 1067, date '2018/4/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(230, 1096, date '2017/12/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(230, 2899, date '2016/6/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(230, 1918, date '2018/5/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(231, 1187, date '2016/9/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(231, 1597, date '2018/1/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(231, 2016, date '2015/7/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(231, 359, date '2017/7/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(232, 2124, date '2017/9/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(234, 739, date '2016/3/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(235, 729, date '2016/2/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(235, 2664, date '2017/10/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(235, 1804, date '2019/10/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(236, 3519, date '2018/6/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(236, 2650, date '2018/9/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(236, 225, date '2016/3/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(237, 3857, date '2017/6/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(237, 2830, date '2019/9/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(237, 2232, date '2017/9/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(237, 1309, date '2015/3/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(238, 1538, date '2019/3/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(238, 3847, date '2017/9/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(239, 1833, date '2015/6/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(240, 2998, date '2015/4/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(241, 1209, date '2018/6/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(241, 368, date '2016/4/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(241, 1392, date '2019/12/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(242, 401, date '2016/7/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(242, 3195, date '2017/10/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(242, 562, date '2015/5/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(243, 3340, date '2019/1/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(243, 3008, date '2018/11/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(243, 2429, date '2017/12/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(243, 1492, date '2016/11/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(244, 97, date '2017/5/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(245, 2698, date '2015/1/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(245, 1353, date '2019/7/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(246, 3246, date '2019/10/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(248, 1925, date '2019/5/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(250, 3441, date '2017/8/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(250, 3407, date '2019/3/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(251, 2175, date '2019/6/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(251, 3898, date '2015/7/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(252, 3082, date '2018/1/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(252, 1843, date '2016/12/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(252, 1418, date '2018/7/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(252, 2618, date '2015/11/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(253, 3683, date '2018/8/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(254, 3773, date '2016/10/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(254, 596, date '2019/3/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(254, 118, date '2017/6/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(255, 1111, date '2015/5/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(255, 1066, date '2019/7/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(256, 1828, date '2018/12/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(256, 3662, date '2019/10/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(257, 1333, date '2018/1/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(258, 1954, date '2019/11/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(258, 2604, date '2018/8/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(259, 1923, date '2017/10/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(260, 2190, date '2018/2/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(260, 3606, date '2017/2/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(260, 330, date '2015/11/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(260, 3091, date '2016/6/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(261, 3103, date '2017/3/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(261, 2007, date '2018/2/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(262, 2145, date '2018/5/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(262, 1448, date '2016/2/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(262, 2586, date '2019/10/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(263, 1632, date '2015/5/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(263, 3681, date '2015/6/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(263, 186, date '2015/7/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(263, 3655, date '2018/9/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(265, 3096, date '2017/5/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(266, 2465, date '2015/5/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(266, 663, date '2015/4/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(266, 1272, date '2015/10/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(267, 1091, date '2017/9/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(268, 117, date '2019/1/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(268, 729, date '2017/11/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(269, 3184, date '2017/2/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(269, 2038, date '2016/12/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(270, 251, date '2018/10/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(271, 1468, date '2016/2/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(271, 312, date '2018/9/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(271, 3004, date '2018/7/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(271, 2521, date '2015/5/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(274, 1909, date '2017/6/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(274, 1048, date '2016/8/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(274, 3768, date '2016/1/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(274, 1748, date '2017/4/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(276, 2054, date '2018/8/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(277, 2946, date '2017/12/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(278, 462, date '2018/11/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(278, 1051, date '2019/7/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(279, 3606, date '2015/10/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(280, 696, date '2015/10/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(280, 1134, date '2015/5/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(280, 605, date '2019/5/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(281, 2471, date '2018/12/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(281, 34, date '2018/3/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(281, 1243, date '2018/9/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(282, 2894, date '2016/4/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(282, 2697, date '2015/9/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(282, 7, date '2017/12/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(282, 404, date '2016/7/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(283, 2240, date '2018/3/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(283, 621, date '2018/10/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(283, 223, date '2019/8/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(283, 3030, date '2016/5/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(284, 220, date '2016/11/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(285, 2963, date '2016/3/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(285, 3555, date '2018/4/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(285, 3800, date '2017/11/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(285, 875, date '2016/2/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(287, 1354, date '2019/1/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(287, 3863, date '2015/12/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(287, 2962, date '2017/4/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(287, 2843, date '2018/10/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(288, 3487, date '2019/5/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(288, 3247, date '2018/9/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(288, 2633, date '2019/6/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(288, 2321, date '2019/2/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(290, 1253, date '2019/10/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(290, 725, date '2015/12/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(290, 2492, date '2017/4/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(290, 3404, date '2018/5/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(291, 3503, date '2019/9/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(291, 817, date '2016/12/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(291, 1532, date '2019/11/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(292, 178, date '2016/2/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(294, 2359, date '2017/6/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(294, 3392, date '2015/9/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(294, 1047, date '2019/10/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(295, 896, date '2016/4/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(296, 630, date '2019/5/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(298, 781, date '2019/11/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(299, 2310, date '2016/7/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(300, 2752, date '2017/7/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(300, 3170, date '2015/3/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(300, 1882, date '2018/6/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(302, 221, date '2015/10/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(303, 1003, date '2017/6/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(303, 3295, date '2019/9/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(303, 3847, date '2019/5/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(303, 1318, date '2017/6/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(304, 672, date '2019/7/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(304, 3355, date '2019/12/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(304, 1107, date '2017/7/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(304, 26, date '2018/1/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(306, 1882, date '2018/5/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(306, 3035, date '2016/4/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(306, 785, date '2017/1/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(306, 1874, date '2016/12/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(308, 3704, date '2016/2/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(308, 2915, date '2015/10/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(308, 2558, date '2016/2/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(309, 3844, date '2017/1/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(310, 2952, date '2016/4/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(310, 1920, date '2017/4/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(310, 115, date '2015/1/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(314, 476, date '2019/11/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(315, 856, date '2019/2/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(315, 1761, date '2015/6/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(316, 1, date '2019/8/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(316, 1730, date '2018/2/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(317, 3552, date '2018/12/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(318, 3718, date '2017/11/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(318, 1020, date '2015/8/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(319, 1096, date '2018/6/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(319, 2383, date '2019/8/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(320, 736, date '2016/8/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(320, 250, date '2017/10/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(320, 2782, date '2017/5/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(322, 1931, date '2015/11/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(322, 515, date '2016/10/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(322, 3767, date '2016/7/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(323, 2937, date '2017/2/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(323, 1295, date '2015/6/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(324, 2281, date '2018/12/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(325, 1481, date '2015/1/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(326, 484, date '2017/1/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(326, 2901, date '2017/4/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(328, 3489, date '2019/9/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(328, 1089, date '2015/12/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(328, 2853, date '2016/6/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(330, 2287, date '2017/5/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(330, 1801, date '2017/9/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(330, 3860, date '2015/9/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(330, 3111, date '2019/5/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(331, 406, date '2018/3/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(332, 851, date '2015/7/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(332, 2407, date '2017/10/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(334, 1565, date '2016/6/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(335, 2574, date '2017/10/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(335, 431, date '2015/9/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(336, 3459, date '2016/10/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(336, 1802, date '2015/3/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(337, 3222, date '2019/7/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(337, 2663, date '2018/11/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(337, 2867, date '2018/1/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(337, 2707, date '2016/7/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(338, 102, date '2017/9/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(338, 1307, date '2019/1/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(338, 2374, date '2018/8/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(339, 2521, date '2019/4/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(339, 2072, date '2017/11/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(339, 3706, date '2018/1/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(339, 3605, date '2015/8/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(340, 2476, date '2015/3/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(340, 3325, date '2019/10/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(341, 2268, date '2017/6/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(341, 3826, date '2016/11/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(343, 799, date '2018/7/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(343, 2872, date '2017/6/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(343, 1327, date '2018/8/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(344, 3120, date '2019/11/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(345, 3109, date '2018/4/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(346, 3666, date '2017/2/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(347, 2981, date '2016/9/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(347, 2970, date '2016/2/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(347, 1389, date '2017/6/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(348, 2508, date '2015/8/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(348, 3327, date '2016/7/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(348, 1721, date '2019/7/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(348, 1971, date '2018/1/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(350, 1800, date '2016/5/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(350, 3629, date '2018/1/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(350, 1554, date '2016/9/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(353, 930, date '2019/10/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(354, 3094, date '2017/1/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(354, 441, date '2019/4/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(355, 295, date '2016/1/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(355, 3207, date '2019/3/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(355, 671, date '2017/2/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(356, 2856, date '2018/8/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(357, 837, date '2018/6/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(357, 3648, date '2015/6/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(357, 2022, date '2016/2/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(357, 2815, date '2016/4/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(358, 1763, date '2018/11/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(358, 1236, date '2018/5/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(358, 293, date '2017/4/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(358, 3593, date '2015/8/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(359, 252, date '2015/9/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(359, 1447, date '2019/8/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(359, 694, date '2016/2/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(359, 882, date '2017/3/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(360, 1486, date '2017/4/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(360, 1177, date '2018/4/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(361, 1491, date '2019/5/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(361, 954, date '2016/3/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(361, 594, date '2019/11/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(361, 778, date '2017/12/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(362, 539, date '2015/5/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(362, 1438, date '2015/9/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(363, 1467, date '2019/11/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(363, 675, date '2016/9/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(363, 1228, date '2019/11/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(363, 540, date '2016/6/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(364, 2359, date '2016/2/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(364, 763, date '2019/1/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(364, 2826, date '2019/10/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(365, 3609, date '2015/9/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(365, 3570, date '2015/1/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(367, 2495, date '2019/10/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(367, 1145, date '2018/11/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(367, 3496, date '2019/4/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(368, 3118, date '2015/5/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(368, 435, date '2019/9/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(369, 2231, date '2015/2/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(369, 2098, date '2017/10/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(369, 1347, date '2017/9/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(369, 3267, date '2018/5/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(371, 448, date '2015/7/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(371, 1930, date '2019/7/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(372, 2933, date '2016/12/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(372, 3791, date '2018/1/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(373, 1139, date '2016/10/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(373, 3795, date '2017/10/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(374, 1608, date '2017/4/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(375, 320, date '2015/8/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(375, 2134, date '2016/10/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(376, 2768, date '2016/11/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(376, 2548, date '2015/6/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(377, 2092, date '2018/9/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(377, 951, date '2019/3/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(377, 3192, date '2018/6/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(377, 2831, date '2019/9/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(378, 3603, date '2017/3/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(378, 2320, date '2018/1/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(378, 554, date '2015/12/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(378, 2242, date '2016/7/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(380, 1801, date '2016/1/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(380, 687, date '2015/2/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(381, 2779, date '2017/1/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(381, 3470, date '2019/7/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(381, 2415, date '2016/1/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(381, 387, date '2017/8/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(382, 2801, date '2018/2/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(382, 2998, date '2017/3/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(382, 639, date '2019/2/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(382, 3827, date '2016/12/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(383, 1531, date '2019/4/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(383, 355, date '2016/8/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(384, 1847, date '2016/12/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(386, 284, date '2018/10/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(386, 374, date '2015/12/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(387, 160, date '2017/11/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(387, 3523, date '2017/3/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(388, 3112, date '2019/6/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(388, 752, date '2016/10/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(388, 2096, date '2016/8/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(388, 1383, date '2019/12/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(389, 3796, date '2016/11/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(389, 2717, date '2019/6/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(389, 3014, date '2015/10/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(389, 3885, date '2017/2/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(390, 3702, date '2015/4/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(390, 2351, date '2015/12/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(391, 922, date '2015/5/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(391, 2814, date '2016/3/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(391, 3097, date '2016/3/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(392, 2937, date '2015/8/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(392, 1606, date '2015/1/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(393, 3139, date '2016/2/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(394, 881, date '2018/4/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(394, 402, date '2018/4/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(395, 528, date '2018/4/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(396, 1288, date '2017/10/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(396, 1618, date '2016/2/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(396, 2627, date '2018/8/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(396, 3388, date '2018/12/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(397, 1410, date '2016/6/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(397, 332, date '2015/2/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(397, 2426, date '2017/6/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(397, 2816, date '2015/2/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(398, 1658, date '2017/11/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(398, 1801, date '2017/10/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(399, 3229, date '2019/5/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(399, 3225, date '2017/12/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(399, 2765, date '2017/1/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(399, 1968, date '2018/1/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(400, 848, date '2019/2/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(400, 3755, date '2018/9/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(400, 3799, date '2016/12/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(400, 1627, date '2018/11/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(401, 3064, date '2015/9/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(401, 129, date '2015/2/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(401, 1903, date '2017/12/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(402, 640, date '2019/8/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(403, 1146, date '2018/6/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(404, 3304, date '2016/2/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(405, 815, date '2015/12/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(407, 1097, date '2017/7/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(407, 3457, date '2015/3/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(407, 2262, date '2015/4/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(408, 3164, date '2016/1/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(409, 2869, date '2015/4/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(409, 1141, date '2017/11/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(409, 2234, date '2016/11/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(409, 1047, date '2018/8/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(410, 2201, date '2016/9/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(410, 2291, date '2015/2/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(411, 1244, date '2017/4/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(413, 2118, date '2018/9/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(413, 2479, date '2017/12/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(413, 2502, date '2017/12/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(414, 1088, date '2019/3/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(415, 1160, date '2016/6/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(415, 2014, date '2018/4/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(415, 1164, date '2016/6/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(415, 324, date '2019/12/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(417, 1465, date '2015/9/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(417, 1578, date '2018/4/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(417, 987, date '2016/7/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(418, 862, date '2015/4/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(418, 3261, date '2015/1/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(418, 1233, date '2017/2/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(418, 3419, date '2015/11/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(419, 928, date '2016/2/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(419, 1018, date '2019/2/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(419, 3299, date '2019/8/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(420, 964, date '2019/3/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(421, 2281, date '2019/11/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(421, 3776, date '2018/6/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(421, 2967, date '2019/3/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(422, 2120, date '2015/4/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(422, 1349, date '2016/5/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(422, 1323, date '2015/12/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(422, 1022, date '2019/8/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(423, 913, date '2016/11/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(423, 3491, date '2017/4/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(423, 3679, date '2017/9/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(424, 3243, date '2017/9/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(424, 751, date '2019/10/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(424, 446, date '2018/5/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(424, 3815, date '2018/1/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(425, 2266, date '2016/11/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(425, 766, date '2018/1/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(425, 672, date '2015/11/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(426, 3791, date '2017/4/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(426, 3755, date '2018/7/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(426, 3164, date '2016/5/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(428, 885, date '2015/4/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(428, 2270, date '2019/12/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(428, 1795, date '2017/8/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(429, 2757, date '2017/10/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(429, 2934, date '2018/2/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(429, 337, date '2016/8/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(430, 505, date '2019/11/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(431, 1645, date '2015/9/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(432, 2435, date '2018/4/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(432, 516, date '2015/2/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(433, 3204, date '2017/3/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(433, 1081, date '2019/3/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(433, 875, date '2016/4/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(436, 1975, date '2019/6/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(436, 2195, date '2016/10/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(436, 3332, date '2019/5/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(436, 2217, date '2018/2/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(437, 2630, date '2015/8/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(437, 2922, date '2015/3/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(437, 3791, date '2015/5/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(437, 663, date '2018/4/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(438, 3484, date '2017/10/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(438, 314, date '2017/7/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(439, 512, date '2017/11/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(440, 1554, date '2019/11/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(440, 2456, date '2015/8/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(441, 1661, date '2015/9/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(441, 2442, date '2016/8/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(442, 3650, date '2017/11/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(442, 3118, date '2017/5/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(442, 2846, date '2016/6/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(442, 2056, date '2015/1/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(443, 1090, date '2015/5/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(443, 2464, date '2015/2/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(444, 2659, date '2015/11/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(444, 590, date '2017/1/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(444, 509, date '2017/12/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(444, 385, date '2018/5/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(445, 1568, date '2017/2/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(446, 897, date '2015/10/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(446, 177, date '2018/3/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(447, 1918, date '2019/4/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(447, 500, date '2018/2/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(447, 2841, date '2019/5/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(449, 1646, date '2019/9/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(449, 573, date '2016/8/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(450, 2952, date '2019/5/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(451, 2584, date '2016/9/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(451, 2249, date '2018/6/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(451, 1093, date '2015/3/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(451, 951, date '2018/8/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(452, 1564, date '2015/11/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(452, 3464, date '2017/1/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(453, 2996, date '2016/4/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(455, 3323, date '2019/11/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(455, 3179, date '2019/5/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(455, 1020, date '2018/5/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(456, 232, date '2017/5/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(456, 356, date '2019/2/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(456, 482, date '2015/1/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(456, 3430, date '2019/7/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(458, 3200, date '2017/2/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(460, 1548, date '2016/9/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(460, 849, date '2016/4/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(460, 780, date '2019/11/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(460, 75, date '2017/11/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(461, 3467, date '2018/6/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(461, 1018, date '2017/7/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(461, 1900, date '2015/2/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(462, 3702, date '2016/10/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(462, 348, date '2015/9/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(463, 3411, date '2016/2/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(464, 3424, date '2016/9/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(464, 3191, date '2015/1/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(465, 2571, date '2018/6/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(466, 691, date '2016/6/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(466, 70, date '2017/8/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(466, 1033, date '2016/10/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(468, 1337, date '2018/8/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(468, 2540, date '2015/7/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(468, 1057, date '2018/11/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(468, 1929, date '2015/5/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(469, 1299, date '2018/4/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(469, 1841, date '2015/12/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(469, 2358, date '2017/9/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(469, 1388, date '2019/6/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(470, 1342, date '2015/11/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(472, 2427, date '2018/11/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(472, 2044, date '2016/10/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(473, 2840, date '2015/2/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(473, 3887, date '2016/8/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(473, 3027, date '2018/12/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(473, 1567, date '2018/8/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(475, 1693, date '2019/3/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(475, 2102, date '2015/9/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(475, 1877, date '2018/6/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(475, 1182, date '2017/1/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(476, 328, date '2018/1/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(476, 2094, date '2015/11/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(476, 1021, date '2019/12/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(476, 484, date '2017/4/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(477, 3402, date '2016/11/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(477, 1326, date '2016/5/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(477, 3571, date '2018/9/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(477, 352, date '2019/4/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(478, 1998, date '2015/9/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(478, 1017, date '2017/11/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(478, 729, date '2015/8/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(478, 1321, date '2016/4/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(479, 1522, date '2018/11/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(480, 2976, date '2019/2/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(480, 1309, date '2016/8/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(480, 3061, date '2016/12/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(480, 101, date '2018/11/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(481, 1235, date '2019/12/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(481, 1360, date '2018/4/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(482, 3880, date '2018/2/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(482, 2392, date '2019/12/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(482, 1490, date '2015/9/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(482, 830, date '2019/1/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(483, 3461, date '2019/7/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(483, 1800, date '2018/7/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(483, 647, date '2015/1/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(483, 2717, date '2018/7/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(484, 2573, date '2018/2/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(484, 3786, date '2019/11/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(485, 2111, date '2016/11/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(486, 421, date '2016/1/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(486, 688, date '2015/8/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(486, 1774, date '2015/2/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(486, 3432, date '2018/4/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(487, 2779, date '2017/8/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(488, 3366, date '2016/8/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(489, 317, date '2017/7/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(489, 1693, date '2019/5/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(489, 209, date '2018/4/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(491, 1745, date '2018/11/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(491, 281, date '2015/7/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(491, 1226, date '2019/7/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(491, 2077, date '2019/5/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(492, 3406, date '2016/5/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(492, 2973, date '2019/5/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(492, 975, date '2016/9/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(493, 914, date '2018/12/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(493, 1605, date '2016/8/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(493, 739, date '2019/4/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(494, 2156, date '2015/9/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(494, 1562, date '2015/7/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(494, 3785, date '2015/5/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(495, 2218, date '2017/9/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(496, 837, date '2018/3/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(497, 3082, date '2016/3/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(497, 1486, date '2015/3/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(498, 2287, date '2016/11/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(498, 3207, date '2019/10/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(499, 12, date '2018/1/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(499, 1404, date '2019/8/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(499, 2380, date '2015/4/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(500, 1902, date '2018/1/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(501, 2748, date '2015/2/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(501, 1386, date '2015/2/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(501, 2737, date '2018/12/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(501, 2010, date '2016/4/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(502, 357, date '2019/10/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(504, 586, date '2019/2/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(504, 1994, date '2019/9/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(505, 2068, date '2015/1/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(505, 3872, date '2018/7/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(505, 2147, date '2018/12/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(507, 1051, date '2015/1/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(508, 1096, date '2015/10/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(509, 964, date '2016/9/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(509, 2096, date '2018/2/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(509, 1156, date '2018/6/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(509, 199, date '2015/7/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(510, 739, date '2015/7/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(510, 1796, date '2015/4/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(510, 1367, date '2017/6/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(510, 258, date '2017/1/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(511, 2522, date '2018/3/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(512, 3735, date '2017/3/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(512, 3797, date '2018/11/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(512, 656, date '2017/4/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(512, 1777, date '2019/9/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(513, 3838, date '2019/10/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(513, 2328, date '2016/3/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(513, 1745, date '2019/12/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(514, 1512, date '2015/10/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(516, 1880, date '2018/5/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(517, 914, date '2019/2/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(518, 1047, date '2019/6/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(518, 1788, date '2018/4/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(519, 691, date '2016/8/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(519, 2002, date '2018/4/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(521, 2824, date '2016/4/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(521, 3450, date '2019/12/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(521, 2135, date '2017/3/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(522, 3759, date '2018/4/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(523, 2860, date '2019/7/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(523, 631, date '2019/11/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(524, 3773, date '2018/8/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(524, 2088, date '2017/8/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(525, 2021, date '2017/7/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(526, 856, date '2018/12/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(526, 3038, date '2015/3/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(526, 3290, date '2017/10/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(526, 2699, date '2018/2/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(527, 589, date '2015/11/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(528, 1117, date '2015/4/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(528, 2903, date '2018/12/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(528, 2796, date '2015/4/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(528, 1625, date '2016/12/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(530, 687, date '2018/6/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(530, 2145, date '2019/8/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(531, 2049, date '2017/10/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(531, 1550, date '2015/2/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(531, 3774, date '2015/8/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(532, 3443, date '2019/2/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(532, 22, date '2017/3/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(533, 1757, date '2017/2/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(533, 1737, date '2017/8/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(535, 1526, date '2017/9/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(535, 3446, date '2016/6/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(536, 2731, date '2019/4/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(537, 1489, date '2016/1/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(537, 2148, date '2017/9/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(537, 3116, date '2019/7/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(538, 1990, date '2016/4/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(538, 2896, date '2019/12/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(538, 1280, date '2016/9/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(541, 2929, date '2019/3/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(541, 724, date '2017/2/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(541, 1932, date '2019/5/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(542, 435, date '2015/7/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(542, 105, date '2015/5/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(543, 1396, date '2015/1/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(543, 2364, date '2017/10/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(543, 1581, date '2018/8/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(544, 1861, date '2019/11/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(544, 133, date '2016/8/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(544, 657, date '2017/10/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(547, 1154, date '2019/11/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(547, 2440, date '2019/10/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(547, 1109, date '2019/12/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(549, 3333, date '2019/11/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(549, 597, date '2019/12/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(550, 2095, date '2019/9/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(550, 1319, date '2017/1/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(551, 101, date '2017/7/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(552, 465, date '2016/9/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(552, 2166, date '2019/4/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(552, 1129, date '2015/4/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(552, 3845, date '2015/11/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(553, 3721, date '2015/7/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(553, 225, date '2016/11/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(553, 1083, date '2015/12/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(554, 3480, date '2019/5/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(554, 3639, date '2016/4/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(554, 2573, date '2015/3/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(555, 3538, date '2018/6/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(555, 2469, date '2016/8/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(555, 358, date '2017/7/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(556, 3322, date '2016/9/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(557, 1877, date '2015/5/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(557, 1924, date '2017/10/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(557, 573, date '2018/6/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(558, 3327, date '2016/12/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(558, 2284, date '2019/12/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(558, 3131, date '2017/1/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(559, 2721, date '2015/6/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(559, 2397, date '2019/8/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(560, 2921, date '2018/5/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(561, 2357, date '2015/11/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(561, 1645, date '2015/10/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(561, 3377, date '2016/10/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(561, 2727, date '2019/8/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(562, 896, date '2016/4/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(562, 733, date '2015/12/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(562, 1302, date '2018/10/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(563, 1213, date '2017/12/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(563, 3457, date '2016/12/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(564, 1577, date '2016/7/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(564, 3135, date '2017/9/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(564, 115, date '2018/7/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(564, 2495, date '2017/1/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(565, 1212, date '2016/9/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(565, 943, date '2018/6/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(567, 3070, date '2017/3/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(567, 455, date '2017/8/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(567, 3867, date '2017/6/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(567, 1951, date '2018/2/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(569, 3323, date '2018/4/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(569, 3485, date '2017/9/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(569, 626, date '2019/6/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(570, 195, date '2019/2/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(570, 2546, date '2017/2/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(570, 1108, date '2018/7/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(571, 3028, date '2018/6/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(571, 1949, date '2018/9/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(572, 902, date '2016/4/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(574, 3890, date '2015/1/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(574, 1380, date '2016/9/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(575, 2859, date '2019/6/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(575, 3283, date '2018/2/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(576, 1995, date '2019/5/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(576, 359, date '2019/8/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(576, 2236, date '2015/1/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(576, 2790, date '2016/10/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(577, 1536, date '2016/5/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(577, 2886, date '2016/10/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(577, 3087, date '2017/8/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(577, 3816, date '2015/12/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(578, 2163, date '2018/10/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(578, 2637, date '2017/9/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(579, 2080, date '2015/6/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(579, 1540, date '2015/2/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(580, 869, date '2018/1/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(580, 2899, date '2017/4/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(580, 1701, date '2019/8/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(581, 3040, date '2018/12/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(584, 1105, date '2019/5/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(584, 333, date '2019/11/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(585, 276, date '2016/11/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(585, 2925, date '2017/1/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(585, 1831, date '2015/12/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(585, 3551, date '2015/7/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(586, 573, date '2019/5/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(586, 2583, date '2018/1/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(586, 620, date '2019/1/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(586, 2737, date '2015/3/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(589, 1891, date '2016/3/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(589, 2910, date '2015/7/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(589, 2781, date '2019/7/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(590, 164, date '2015/3/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(591, 3283, date '2017/2/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(591, 1553, date '2018/7/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(591, 2251, date '2019/10/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(592, 2388, date '2017/3/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(592, 3381, date '2016/10/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(592, 442, date '2017/4/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(592, 1390, date '2018/1/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(593, 23, date '2015/8/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(594, 421, date '2015/4/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(595, 2841, date '2015/5/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(595, 2385, date '2015/6/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(595, 2432, date '2016/11/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(596, 458, date '2016/9/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(596, 3701, date '2018/8/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(596, 1325, date '2015/1/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(596, 3682, date '2016/1/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(598, 3471, date '2015/12/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(598, 2153, date '2015/1/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(599, 1540, date '2018/3/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(601, 3172, date '2017/10/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(602, 3190, date '2017/2/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(602, 2191, date '2015/5/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(602, 1293, date '2016/3/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(602, 1486, date '2018/5/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(604, 1774, date '2019/7/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(604, 3084, date '2015/11/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(604, 1134, date '2017/1/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(604, 1226, date '2015/2/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(605, 2998, date '2015/4/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(606, 185, date '2018/5/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(606, 2529, date '2017/4/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(607, 3348, date '2016/12/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(607, 632, date '2017/2/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(607, 2184, date '2015/12/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(607, 2297, date '2017/1/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(609, 866, date '2019/9/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(609, 115, date '2018/6/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(610, 1229, date '2018/9/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(610, 242, date '2015/12/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(610, 1415, date '2015/7/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(610, 1408, date '2015/11/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(611, 1511, date '2015/8/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(611, 865, date '2019/4/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(611, 3576, date '2018/2/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(611, 576, date '2016/7/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(612, 2728, date '2019/4/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(614, 3511, date '2016/8/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(614, 1762, date '2018/2/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(615, 1396, date '2019/5/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(616, 3859, date '2015/4/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(616, 2425, date '2018/10/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(616, 2464, date '2019/9/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(617, 604, date '2019/7/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(617, 1416, date '2018/3/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(617, 3751, date '2019/8/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(617, 3196, date '2016/10/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(619, 2820, date '2015/3/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(619, 2831, date '2019/11/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(619, 3735, date '2019/8/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(619, 1040, date '2019/11/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(620, 2673, date '2018/11/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(620, 3755, date '2018/6/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(621, 3260, date '2017/7/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(622, 124, date '2019/3/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(622, 3148, date '2019/3/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(623, 438, date '2016/8/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(623, 3187, date '2017/9/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(623, 2487, date '2015/11/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(624, 538, date '2016/2/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(624, 2187, date '2019/9/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(624, 1779, date '2019/6/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(624, 3403, date '2019/5/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(625, 2063, date '2016/8/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(625, 2617, date '2019/7/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(625, 1019, date '2019/1/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(625, 1077, date '2015/9/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(627, 454, date '2018/10/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(627, 2040, date '2018/9/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(627, 3536, date '2017/5/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(628, 1359, date '2016/5/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(628, 996, date '2016/12/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(628, 1366, date '2015/10/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(630, 2222, date '2018/4/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(631, 14, date '2017/7/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(631, 1739, date '2015/12/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(631, 1522, date '2015/1/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(631, 1572, date '2017/2/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(632, 2757, date '2016/5/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(632, 3452, date '2016/5/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(632, 387, date '2016/3/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(633, 1167, date '2019/8/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(633, 3248, date '2018/5/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(634, 751, date '2018/8/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(635, 2035, date '2015/9/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(635, 2962, date '2015/1/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(636, 1755, date '2016/3/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(636, 2853, date '2019/12/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(636, 1096, date '2016/2/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(636, 1115, date '2019/5/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(637, 1056, date '2017/1/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(637, 241, date '2015/5/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(638, 1834, date '2019/8/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(639, 2918, date '2019/3/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(639, 2458, date '2019/10/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(639, 1027, date '2015/1/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(640, 699, date '2015/12/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(642, 2198, date '2018/7/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(642, 1191, date '2015/9/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(642, 2051, date '2016/11/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(642, 3779, date '2016/9/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(643, 1948, date '2017/11/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(644, 650, date '2018/5/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(644, 572, date '2019/10/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(644, 2510, date '2019/10/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(645, 2636, date '2018/4/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(645, 2298, date '2018/1/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(646, 1713, date '2016/3/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(647, 612, date '2017/3/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(648, 3826, date '2016/11/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(648, 2573, date '2019/3/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(648, 3290, date '2015/1/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(649, 378, date '2015/2/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(649, 1856, date '2019/2/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(649, 3196, date '2017/1/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(650, 1523, date '2015/8/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(650, 1657, date '2019/6/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(651, 187, date '2015/12/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(652, 1327, date '2017/2/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(653, 1460, date '2017/12/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(653, 965, date '2018/3/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(653, 2673, date '2019/6/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(653, 2300, date '2016/6/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(654, 1699, date '2016/6/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(655, 754, date '2017/5/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(655, 899, date '2019/3/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(656, 754, date '2019/5/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(657, 3450, date '2017/5/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(657, 1541, date '2017/6/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(657, 1510, date '2015/11/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(657, 217, date '2018/11/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(659, 2018, date '2018/4/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(659, 3550, date '2017/9/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(659, 3098, date '2018/4/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(659, 3503, date '2016/7/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(661, 2968, date '2018/9/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(661, 3308, date '2018/3/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(661, 3856, date '2016/3/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(663, 3093, date '2015/11/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(663, 639, date '2015/2/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(663, 37, date '2016/6/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(664, 729, date '2018/2/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(664, 3269, date '2017/6/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(665, 2451, date '2019/4/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(665, 514, date '2018/5/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(667, 3630, date '2017/1/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(667, 336, date '2018/1/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(667, 3013, date '2017/6/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(667, 986, date '2017/3/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(669, 2114, date '2018/12/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(670, 2407, date '2019/5/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(670, 3141, date '2019/6/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(670, 2778, date '2018/2/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(672, 3662, date '2019/7/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(672, 1124, date '2019/9/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(672, 1534, date '2019/8/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(673, 2260, date '2019/6/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(673, 2493, date '2015/9/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(673, 1648, date '2015/5/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(673, 956, date '2017/7/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(674, 3531, date '2017/11/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(674, 1182, date '2018/6/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(675, 885, date '2016/5/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(675, 1737, date '2017/2/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(675, 3354, date '2017/11/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(676, 1361, date '2015/9/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(677, 2021, date '2018/2/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(677, 1369, date '2017/9/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(678, 3468, date '2018/3/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(680, 1883, date '2019/11/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(680, 610, date '2015/8/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(680, 406, date '2019/9/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(680, 3320, date '2018/7/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(682, 3326, date '2015/2/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(682, 1064, date '2016/3/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(682, 3320, date '2017/10/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(683, 2201, date '2017/5/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(684, 2196, date '2015/9/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(684, 568, date '2017/12/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(685, 877, date '2015/4/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(685, 3576, date '2016/10/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(686, 582, date '2019/2/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(686, 3566, date '2015/11/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(687, 2526, date '2018/11/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(687, 839, date '2017/2/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(688, 1048, date '2015/11/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(688, 2493, date '2016/12/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(688, 1954, date '2016/5/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(688, 3192, date '2016/7/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(689, 142, date '2017/7/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(689, 3675, date '2016/8/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(690, 3791, date '2016/9/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(690, 3342, date '2017/2/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(690, 1602, date '2018/4/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(691, 830, date '2017/7/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(691, 888, date '2015/4/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(691, 1836, date '2016/6/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(692, 876, date '2018/3/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(692, 2066, date '2018/2/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(692, 1411, date '2015/2/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(693, 1636, date '2015/6/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(693, 2293, date '2017/12/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(693, 3731, date '2018/10/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(694, 815, date '2018/4/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(695, 1017, date '2017/8/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(695, 2123, date '2016/5/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(696, 2556, date '2018/12/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(696, 2537, date '2015/10/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(697, 1592, date '2018/11/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(697, 2379, date '2016/7/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(697, 3803, date '2019/2/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(698, 383, date '2015/11/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(698, 934, date '2015/4/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(698, 2900, date '2018/6/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(699, 2218, date '2019/1/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(700, 1598, date '2018/9/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(701, 3417, date '2016/3/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(701, 1397, date '2016/7/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(701, 3806, date '2017/5/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(702, 432, date '2015/3/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(703, 421, date '2019/1/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(703, 1779, date '2019/7/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(704, 1560, date '2017/5/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(704, 3279, date '2016/4/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(705, 580, date '2019/11/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(705, 330, date '2017/3/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(705, 1576, date '2019/8/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(705, 303, date '2018/5/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(706, 1709, date '2017/1/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(707, 48, date '2016/7/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(707, 3384, date '2018/3/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(707, 959, date '2017/4/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(709, 2613, date '2017/11/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(709, 1695, date '2017/11/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(709, 107, date '2017/5/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(709, 902, date '2015/8/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(710, 1612, date '2019/2/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(711, 465, date '2019/5/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(711, 609, date '2016/9/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(711, 1240, date '2016/12/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(711, 3509, date '2018/11/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(712, 201, date '2015/12/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(713, 3037, date '2017/10/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(713, 2829, date '2016/5/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(713, 1679, date '2019/9/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(713, 653, date '2015/7/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(714, 2548, date '2016/4/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(714, 1293, date '2015/4/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(715, 3649, date '2019/7/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(715, 3195, date '2018/6/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(716, 930, date '2015/6/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(716, 14, date '2017/7/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(716, 2360, date '2019/8/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(717, 3275, date '2016/2/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(718, 1523, date '2015/5/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(718, 1914, date '2017/3/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(718, 2977, date '2018/6/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(718, 3805, date '2017/12/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(719, 653, date '2019/4/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(719, 1110, date '2015/11/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(719, 2847, date '2019/8/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(720, 3354, date '2019/11/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(720, 670, date '2017/4/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(722, 1886, date '2019/1/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(722, 2651, date '2019/11/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(723, 1376, date '2017/3/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(723, 953, date '2016/7/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(723, 569, date '2015/8/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(724, 3072, date '2017/1/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(725, 80, date '2019/2/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(725, 2027, date '2018/11/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(725, 1968, date '2018/2/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(726, 1767, date '2018/11/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(726, 2478, date '2019/7/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(726, 3016, date '2018/8/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(726, 3664, date '2016/6/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(727, 2729, date '2016/1/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(727, 139, date '2016/8/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(728, 2012, date '2015/2/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(728, 3742, date '2015/12/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(729, 991, date '2017/8/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(729, 1943, date '2018/2/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(730, 1843, date '2018/2/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(730, 1029, date '2018/4/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(730, 2305, date '2017/1/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(731, 1211, date '2018/2/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(732, 2395, date '2018/2/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(732, 1114, date '2015/5/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(732, 906, date '2018/7/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(733, 2776, date '2018/5/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(733, 2748, date '2017/3/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(733, 1264, date '2017/12/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(734, 3355, date '2016/5/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(734, 947, date '2018/1/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(735, 1796, date '2017/2/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(735, 3455, date '2015/8/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(735, 779, date '2018/8/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(735, 1493, date '2016/6/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(736, 2954, date '2019/11/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(736, 725, date '2016/11/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(736, 2141, date '2018/8/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(736, 5, date '2016/12/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(737, 649, date '2016/5/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(737, 2703, date '2017/11/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(737, 2322, date '2017/12/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(737, 2919, date '2017/1/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(739, 1028, date '2019/6/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(739, 324, date '2015/11/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(739, 1656, date '2017/11/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(739, 3146, date '2019/3/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(741, 1637, date '2016/1/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(743, 1369, date '2015/4/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(743, 218, date '2018/12/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(744, 3022, date '2019/11/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(745, 3110, date '2019/7/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(745, 3100, date '2016/7/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(745, 1631, date '2018/5/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(745, 2471, date '2015/2/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(747, 1786, date '2018/2/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(747, 3362, date '2016/12/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(748, 2888, date '2018/4/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(748, 3152, date '2019/1/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(748, 3041, date '2018/4/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(749, 1450, date '2019/6/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(749, 1652, date '2015/11/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(751, 2887, date '2016/9/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(751, 2856, date '2016/6/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(751, 1382, date '2016/5/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(753, 1260, date '2018/6/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(753, 1320, date '2016/4/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(753, 1144, date '2019/10/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(755, 587, date '2017/1/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(755, 3395, date '2019/1/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(755, 3251, date '2015/5/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(756, 1279, date '2015/9/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(756, 2119, date '2018/7/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(757, 2989, date '2015/3/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(758, 1044, date '2019/3/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(758, 802, date '2015/1/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(762, 523, date '2017/5/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(763, 2170, date '2018/3/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(763, 3333, date '2017/10/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(763, 516, date '2015/6/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(764, 3071, date '2015/5/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(764, 2168, date '2017/1/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(764, 3540, date '2017/12/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(764, 826, date '2018/8/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(765, 2013, date '2018/3/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(765, 1456, date '2015/6/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(765, 83, date '2015/4/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(766, 528, date '2017/9/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(766, 645, date '2016/6/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(766, 276, date '2019/3/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(766, 3475, date '2017/6/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(767, 2212, date '2017/12/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(767, 1882, date '2019/4/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(768, 2586, date '2019/2/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(768, 2173, date '2019/2/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(771, 3355, date '2019/4/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(771, 3137, date '2019/3/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(771, 1528, date '2015/4/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(772, 1906, date '2016/6/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(773, 629, date '2019/10/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(773, 442, date '2018/12/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(774, 2057, date '2017/2/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(775, 2116, date '2019/9/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(775, 3071, date '2016/12/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(775, 3665, date '2016/1/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(775, 2763, date '2016/7/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(777, 1543, date '2017/5/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(778, 159, date '2019/10/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(779, 1941, date '2019/5/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(780, 889, date '2017/9/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(780, 2276, date '2017/11/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(781, 535, date '2016/8/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(781, 3589, date '2018/7/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(781, 2439, date '2015/1/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(782, 131, date '2018/1/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(782, 670, date '2017/1/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(782, 3622, date '2017/2/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(783, 3571, date '2018/3/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(783, 3081, date '2015/8/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(785, 1615, date '2018/2/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(785, 1878, date '2017/10/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(785, 3243, date '2018/3/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(785, 1205, date '2016/9/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(786, 2322, date '2016/4/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(786, 289, date '2017/6/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(787, 3623, date '2018/3/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(787, 2624, date '2018/8/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(787, 1973, date '2015/4/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(788, 2524, date '2016/4/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(788, 1342, date '2018/1/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(789, 216, date '2016/2/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(789, 183, date '2018/6/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(789, 962, date '2015/1/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(790, 787, date '2019/9/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(791, 2865, date '2019/4/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(793, 3565, date '2019/2/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(795, 830, date '2019/10/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(797, 1701, date '2019/6/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(797, 132, date '2019/4/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(798, 3426, date '2017/11/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(798, 2395, date '2015/5/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(798, 471, date '2018/2/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(798, 2044, date '2017/2/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(799, 1481, date '2018/3/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(799, 215, date '2018/12/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(799, 1590, date '2016/8/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(800, 350, date '2018/9/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(800, 517, date '2017/6/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(800, 1822, date '2016/11/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(801, 1980, date '2016/12/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(801, 3210, date '2016/7/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(801, 3708, date '2016/5/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(801, 3730, date '2019/11/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(803, 1409, date '2018/11/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(804, 1004, date '2017/7/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(804, 3573, date '2015/2/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(804, 1586, date '2016/10/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(805, 505, date '2017/10/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(805, 3222, date '2015/2/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(805, 548, date '2018/9/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(806, 1023, date '2017/1/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(807, 3161, date '2018/10/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(807, 2476, date '2019/8/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(807, 1319, date '2019/2/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(808, 2135, date '2017/8/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(808, 2616, date '2019/10/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(809, 3164, date '2016/7/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(809, 116, date '2017/5/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(809, 1272, date '2019/12/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(810, 2512, date '2017/8/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(810, 2386, date '2017/3/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(811, 1696, date '2019/11/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(811, 3695, date '2016/9/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(812, 581, date '2019/6/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(812, 385, date '2018/6/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(812, 2715, date '2015/12/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(813, 419, date '2019/10/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(813, 926, date '2019/10/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(813, 774, date '2017/8/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(813, 2548, date '2018/5/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(814, 1028, date '2016/3/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(814, 2643, date '2016/1/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(814, 2379, date '2015/8/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(815, 3875, date '2018/4/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(817, 404, date '2016/11/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(817, 3350, date '2018/2/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(818, 2662, date '2019/4/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(818, 3638, date '2019/2/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(818, 3446, date '2016/6/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(820, 3034, date '2019/5/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(821, 857, date '2019/10/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(821, 3247, date '2017/8/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(821, 1034, date '2016/9/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(821, 3370, date '2015/5/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(822, 801, date '2017/10/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(822, 3710, date '2016/1/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(822, 727, date '2018/6/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(822, 1873, date '2019/10/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(824, 3529, date '2018/3/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(824, 1317, date '2019/3/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(824, 3788, date '2015/2/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(824, 3001, date '2018/2/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(825, 1115, date '2018/4/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(826, 1933, date '2015/2/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(826, 632, date '2017/6/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(829, 1881, date '2016/10/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(830, 3818, date '2015/10/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(830, 3313, date '2016/5/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(830, 2010, date '2019/8/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(831, 316, date '2015/1/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(832, 756, date '2017/4/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(832, 3324, date '2018/5/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(832, 340, date '2015/5/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(833, 2750, date '2019/8/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(833, 2116, date '2017/2/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(833, 1902, date '2019/3/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(835, 1526, date '2019/4/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(835, 3260, date '2016/12/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(835, 3747, date '2016/8/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(836, 2087, date '2017/8/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(836, 698, date '2018/11/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(836, 1757, date '2019/7/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(836, 1595, date '2016/6/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(837, 1535, date '2017/5/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(837, 3267, date '2016/3/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(837, 1934, date '2017/9/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(838, 1397, date '2016/7/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(838, 548, date '2018/6/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(838, 2498, date '2016/2/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(838, 1989, date '2017/7/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(839, 533, date '2018/11/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(840, 3083, date '2018/10/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(841, 234, date '2019/12/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(841, 3339, date '2017/6/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(841, 51, date '2016/11/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(841, 1692, date '2015/7/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(842, 702, date '2018/2/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(843, 3682, date '2017/9/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(843, 3513, date '2019/6/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(843, 221, date '2016/2/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(843, 826, date '2017/9/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(846, 3096, date '2015/4/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(846, 2522, date '2016/9/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(846, 3713, date '2019/12/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(847, 2116, date '2016/8/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(848, 2335, date '2019/6/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(848, 3313, date '2017/12/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(848, 552, date '2015/11/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(849, 533, date '2017/8/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(849, 3477, date '2019/11/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(849, 1807, date '2018/2/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(849, 2032, date '2016/9/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(850, 280, date '2019/9/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(850, 1584, date '2018/10/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(851, 209, date '2018/12/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(851, 3362, date '2015/3/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(851, 1866, date '2018/8/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(852, 3414, date '2016/12/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(854, 2009, date '2015/8/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(854, 123, date '2015/1/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(855, 1164, date '2019/11/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(855, 920, date '2015/6/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(855, 3858, date '2019/8/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(855, 1553, date '2015/12/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(856, 2190, date '2015/9/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(856, 2228, date '2019/11/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(856, 1765, date '2017/12/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(856, 1312, date '2019/4/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(858, 22, date '2017/12/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(858, 197, date '2018/10/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(858, 2803, date '2017/6/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(859, 3858, date '2017/4/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(861, 826, date '2019/5/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(862, 1886, date '2017/3/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(863, 1546, date '2019/12/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(863, 218, date '2019/7/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(863, 1452, date '2019/12/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(863, 1812, date '2018/3/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(864, 1051, date '2015/5/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(864, 1307, date '2018/8/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(865, 317, date '2017/1/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(865, 2751, date '2015/9/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(866, 2597, date '2017/2/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(867, 3286, date '2016/7/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(867, 2167, date '2018/7/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(868, 312, date '2019/3/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(869, 2644, date '2018/7/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(870, 1769, date '2016/3/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(870, 3067, date '2015/9/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(871, 2762, date '2018/1/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(872, 1467, date '2016/10/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(873, 3245, date '2017/9/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(873, 3846, date '2019/1/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(874, 874, date '2019/3/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(875, 2648, date '2018/8/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(875, 1596, date '2016/4/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(878, 2627, date '2018/8/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(879, 592, date '2015/11/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(879, 629, date '2016/2/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(879, 1291, date '2015/11/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(879, 1887, date '2019/9/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(880, 124, date '2015/8/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(880, 786, date '2017/5/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(880, 2259, date '2016/4/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(881, 165, date '2018/4/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(881, 2649, date '2016/10/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(881, 2459, date '2018/8/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(881, 161, date '2016/8/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(882, 3360, date '2019/12/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(883, 2374, date '2015/5/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(883, 1888, date '2017/2/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(883, 1706, date '2018/2/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(883, 2728, date '2019/2/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(884, 1407, date '2017/10/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(885, 1274, date '2017/1/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(885, 3049, date '2017/9/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(885, 2602, date '2018/3/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(885, 3025, date '2015/6/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(887, 672, date '2018/5/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(887, 2159, date '2019/5/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(887, 1730, date '2018/2/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(888, 2720, date '2015/4/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(888, 3108, date '2017/7/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(889, 601, date '2018/1/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(890, 1438, date '2019/6/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(890, 2767, date '2015/4/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(890, 2673, date '2015/9/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(891, 2534, date '2018/7/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(891, 1156, date '2019/10/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(891, 2155, date '2017/9/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(892, 3591, date '2015/6/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(892, 3526, date '2015/11/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(892, 291, date '2018/8/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(893, 3056, date '2016/3/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(894, 1797, date '2016/12/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(896, 1611, date '2015/7/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(896, 2184, date '2015/5/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(897, 674, date '2019/8/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(897, 3548, date '2019/9/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(897, 1267, date '2016/9/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(898, 1749, date '2018/10/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(898, 3182, date '2016/1/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(898, 2785, date '2016/9/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(898, 1136, date '2019/2/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(899, 357, date '2016/3/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(899, 928, date '2016/5/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(900, 3017, date '2017/11/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(901, 1936, date '2015/12/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(901, 3459, date '2019/7/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(904, 2825, date '2016/4/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(904, 287, date '2019/7/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(904, 56, date '2019/12/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(904, 1405, date '2017/12/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(905, 980, date '2017/12/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(905, 1054, date '2015/5/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(906, 3235, date '2016/6/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(906, 1794, date '2017/7/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(906, 2553, date '2019/4/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(907, 1686, date '2018/7/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(907, 1896, date '2019/8/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(908, 375, date '2018/12/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(908, 3275, date '2018/11/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(909, 995, date '2016/3/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(909, 1902, date '2019/5/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(910, 1038, date '2017/7/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(910, 2012, date '2017/7/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(911, 381, date '2017/7/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(911, 3709, date '2019/10/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(911, 2344, date '2016/5/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(912, 2815, date '2019/3/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(912, 2010, date '2016/12/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(912, 873, date '2015/6/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(912, 1152, date '2017/5/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(913, 1392, date '2019/11/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(913, 2490, date '2019/7/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(913, 895, date '2016/10/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(914, 2795, date '2017/1/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(914, 3754, date '2019/11/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(915, 3840, date '2016/7/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(916, 804, date '2018/3/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(916, 996, date '2019/1/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(916, 619, date '2016/6/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(917, 2756, date '2018/2/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(918, 368, date '2016/12/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(919, 1790, date '2019/8/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(920, 2294, date '2019/8/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(920, 787, date '2016/5/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(921, 1572, date '2019/8/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(921, 483, date '2017/9/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(921, 1082, date '2017/5/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(921, 1543, date '2016/4/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(922, 1140, date '2016/5/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(924, 3329, date '2019/11/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(924, 1529, date '2016/4/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(924, 2821, date '2016/1/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(924, 718, date '2015/2/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(925, 1186, date '2018/2/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(925, 359, date '2019/10/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(925, 637, date '2018/2/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(926, 896, date '2016/3/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(928, 3205, date '2017/1/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(928, 442, date '2016/6/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(928, 761, date '2018/11/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(929, 1609, date '2018/4/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(929, 2045, date '2016/3/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(930, 2442, date '2018/4/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(930, 2039, date '2015/9/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(930, 2445, date '2018/4/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(930, 330, date '2017/9/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(931, 1862, date '2015/7/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(931, 2842, date '2017/11/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(932, 1622, date '2016/12/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(932, 1990, date '2018/4/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(932, 1187, date '2017/7/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(932, 52, date '2015/7/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(933, 3294, date '2017/8/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(934, 2084, date '2017/12/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(934, 564, date '2018/9/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(934, 499, date '2019/2/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(935, 904, date '2016/10/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(936, 2479, date '2018/6/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(936, 3543, date '2016/1/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(937, 145, date '2019/1/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(937, 3824, date '2018/9/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(938, 540, date '2018/1/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(938, 272, date '2015/7/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(938, 2101, date '2019/5/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(939, 3718, date '2019/10/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(939, 1993, date '2019/7/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(939, 559, date '2015/10/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(939, 950, date '2018/7/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(942, 1151, date '2015/7/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(942, 1252, date '2019/12/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(942, 782, date '2015/5/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(943, 1800, date '2018/1/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(943, 1691, date '2016/12/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(943, 3461, date '2015/11/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(943, 2377, date '2019/2/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(944, 3223, date '2016/10/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(945, 3583, date '2015/3/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(945, 1164, date '2015/8/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(946, 221, date '2018/4/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(946, 1888, date '2017/10/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(947, 1985, date '2019/6/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(947, 1079, date '2015/11/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(948, 213, date '2016/3/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(948, 723, date '2018/8/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(949, 1658, date '2017/7/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(949, 1526, date '2019/3/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(950, 430, date '2018/11/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(950, 3768, date '2015/3/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(951, 880, date '2017/8/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(951, 730, date '2016/12/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(951, 3374, date '2015/10/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(951, 3342, date '2015/9/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(953, 1921, date '2016/7/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(953, 1205, date '2017/2/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(954, 3142, date '2016/8/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(954, 3173, date '2019/12/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(956, 427, date '2019/10/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(956, 2338, date '2019/8/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(956, 3130, date '2018/4/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(956, 1644, date '2018/11/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(957, 765, date '2019/11/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(957, 558, date '2018/2/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(958, 2073, date '2018/3/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(958, 3285, date '2018/10/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(958, 312, date '2016/2/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(959, 235, date '2018/9/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(959, 1760, date '2016/1/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(959, 2678, date '2017/2/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(960, 3280, date '2017/2/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(961, 2815, date '2018/9/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(961, 50, date '2019/12/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(961, 3525, date '2019/10/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(962, 2878, date '2016/3/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(963, 2373, date '2017/11/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(963, 2791, date '2017/3/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(963, 588, date '2016/8/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(963, 1575, date '2017/6/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(965, 504, date '2017/10/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(966, 1084, date '2019/6/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(966, 3791, date '2019/7/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(966, 3005, date '2019/5/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(966, 63, date '2018/2/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(967, 543, date '2016/10/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(967, 3782, date '2018/1/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(967, 3666, date '2017/4/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(968, 3566, date '2017/2/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(968, 2190, date '2018/3/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(968, 1472, date '2017/2/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(968, 2905, date '2019/1/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(969, 995, date '2017/5/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(970, 150, date '2017/8/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(970, 2946, date '2016/4/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(970, 2264, date '2017/10/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(971, 799, date '2019/3/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(972, 2882, date '2016/1/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(972, 1747, date '2015/12/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(972, 3260, date '2018/11/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(972, 455, date '2015/6/16');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(973, 1423, date '2017/9/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(973, 405, date '2016/8/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(973, 2797, date '2019/7/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(974, 71, date '2019/3/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(977, 1373, date '2019/12/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(977, 3501, date '2016/6/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(978, 3627, date '2015/5/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(978, 1771, date '2015/2/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(978, 3169, date '2017/12/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(979, 3711, date '2019/7/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(979, 129, date '2018/7/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(979, 2624, date '2018/12/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(981, 2694, date '2017/9/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(983, 317, date '2016/9/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(983, 2859, date '2018/3/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(983, 74, date '2016/8/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(984, 2782, date '2019/1/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(984, 2455, date '2016/11/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(984, 678, date '2015/2/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(984, 1857, date '2016/11/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(985, 2181, date '2019/11/24');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(985, 214, date '2016/9/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(985, 2601, date '2016/2/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(986, 1743, date '2016/12/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(986, 2798, date '2016/3/5');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(987, 3097, date '2015/12/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(987, 283, date '2016/1/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(989, 2677, date '2018/11/20');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(989, 2706, date '2015/2/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(990, 1503, date '2015/2/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(990, 707, date '2018/12/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(990, 1360, date '2019/12/14');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(990, 2813, date '2016/10/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(991, 3282, date '2016/11/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(991, 2905, date '2015/12/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(991, 1238, date '2018/9/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(991, 1926, date '2016/7/23');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(992, 3668, date '2015/7/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(994, 914, date '2018/7/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(994, 2135, date '2016/10/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(994, 2448, date '2015/11/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(995, 421, date '2016/6/18');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(996, 2754, date '2015/5/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(996, 237, date '2015/3/11');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(998, 1221, date '2018/10/4');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(998, 2337, date '2016/4/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(998, 486, date '2016/1/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(998, 3400, date '2016/10/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(999, 3214, date '2019/12/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(999, 2035, date '2015/11/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(999, 224, date '2018/4/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1004, 2288, date '2018/1/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1004, 3735, date '2019/7/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1004, 3281, date '2017/12/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1004, 2096, date '2016/10/8');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1005, 3384, date '2018/7/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1005, 1511, date '2017/1/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1005, 3704, date '2016/9/19');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1005, 1341, date '2018/8/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1006, 3751, date '2018/6/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1006, 2438, date '2017/4/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1007, 694, date '2016/6/1');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1007, 3750, date '2015/8/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1007, 3124, date '2016/3/10');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1008, 248, date '2017/6/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1008, 2801, date '2015/9/21');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1008, 3758, date '2018/1/12');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1008, 1013, date '2016/9/22');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1009, 3761, date '2016/10/9');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1009, 109, date '2018/10/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1009, 1383, date '2016/9/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1009, 3131, date '2018/8/2');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1010, 1957, date '2015/3/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1011, 3676, date '2016/1/17');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1012, 2617, date '2019/11/26');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1013, 1027, date '2017/7/13');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1013, 1646, date '2018/5/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1013, 713, date '2017/12/3');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1013, 3297, date '2016/2/15');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1014, 792, date '2019/8/25');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1014, 858, date '2019/11/6');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1014, 2699, date '2016/10/7');

INSERT INTO RentalQueue(MemberId,DVDId,DateAddedInQueue)
VALUES(1014, 1645, date '2019/1/22');

COMMIT;
