CREATE INDEX I_MemberName ON Member(MemberFirstName,MemberLastName);
CREATE INDEX I_PersonName ON MoviePerson(PersonFirstName,PersonLastName);
